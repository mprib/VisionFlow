# learn_networks

A place for me to start to figure out how to use sockets to transmit frame data from an embedded device (i.e. Orange Pi) to a central client. I believe this is the primary component needed to create a scaleable open-source motion capture system. Otherwise, the bottleneck of a single system for pulling down pixels will result in a profound limnitation on number of cameras/available workflows.
